import pyrebase
from flask import Flask

app = Flask(__name__)


import json
# Opening JSON file
with open('../instance/firebaseConfig.json') as f:
    config = json.load(f)
    print(config)



# Application Default credentials are automatically created.
firebase = pyrebase.initialize_app(config)
db = firebase.database()
auth = firebase.auth()
email = 'test1@gmail.com'
password = '123456'
try:
    user = auth.create_user_with_email_and_password(email, password)
    print(user)
except Exception as e:
    pass
finally:
# user = auth.sign_in_with_email_and_password(email, password)
# print(user['idToken'])
# info = auth.get_account_info(user['idToken'])
# print(info)
# sends a verification email to verify email
# auth.send_email_verification(user['idToken'])

# auth.send_password_reset_email(email)


    @app.route('/')
    def hello_world():  # put application's code here
        return 'Hello World!'


if __name__ == '__main__':
    app.run()
